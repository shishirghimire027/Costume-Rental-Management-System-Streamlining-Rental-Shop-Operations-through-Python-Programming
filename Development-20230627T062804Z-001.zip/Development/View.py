#Declaring the dictnary dic_costume
dic_costume={}
#Declariing the function display
def display():
    c=0
    print("*"*50)
    print("ID \tCostume\tBrand \tPrice \tQuantity")
    print("*"*50)
    """Opening the text file in read mode 
    Read the data of the text file to display
    when the user choose the option of view"""
    file=open("Shishir.txt","r")
    costume_book= file.read()
    costume_book=costume_book.split("\n")
    # removes empty string
    while("" in costume_book):
        costume_book.remove("")
    for i in range (len(costume_book)):
        """ASSIGN the value of c as c plus 1 
APPEND the value of c in dic_costume dictionary and ASSIGN its value with spilt of text by comma in costume_book
"""
        c=c+1
        dic_costume[c]=costume_book[i].split(",")
        
    for key,value in dic_costume.items():
        print(key,end="\t")
        for j in value:
            print(j,end="\t")
        print("\n")
#Call the display function
display()