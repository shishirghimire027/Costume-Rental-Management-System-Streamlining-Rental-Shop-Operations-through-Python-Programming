#Importing the sys function
import sys
#Defining the function main
def main():
    while True:
        #Printing the titles of clothing store
            print("*"*60)
            print("          SHISHIR CLOTHING")
            print("*"*60)
            print("          Select an option")
            print("*"*60)
            #printing the options to display options
            print(" Press [1] to VIEW \n Press [2] to RENT \n Press [3] to Return \n Press [4] to Exit")
            a=int(input('''
            ENTER ANY OPTION: '''))
            print("*"*60)
            if a==1:
                #importing the view module
                import View
            elif a==2:
                #importing the rent module
                import Rent
            elif a==3:
                #importing the return module
                import Return
            elif a==4:
                #Existing the program by sys.exit function
                sys.exit("Thank You For trusting us")
            else:
                print("Invalid input")
main()
