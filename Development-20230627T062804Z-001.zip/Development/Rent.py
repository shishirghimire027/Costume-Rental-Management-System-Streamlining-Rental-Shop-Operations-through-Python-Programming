#importing the function datetime function, random, and sys
from datetime import date
import random
import sys

#Getting date 
today = date.today()
day=date.today().day
ID= random.randint(1,1000)
# declaring the dictionaray as dic_costume
dic_costume={}
# declaring the lists
custome_renting=[]
Total=[]
list00=[]
list01=[]
renting=[]


#Defining the display function
def display():
    #count = 0
    c=0
    print("*"*50)
    print("ID \tCostume\tBrand \tPrice \tQuantity")
    print("*"*50)
    #Opening the Shishir.txt file in read mode
    file=open("Shishir.txt","r")
    costume_book= file.read()
    costume_book=costume_book.split("\n")
    
    while("" in costume_book):
        costume_book.remove("")
    for i in range (len(costume_book)):
        c=c+1
        dic_costume[c]=costume_book[i].split(",")
    
    for key,value in dic_costume.items():
        print(key,end="\t")
        for j in value:
            print(j,end="\t")
        print("\n")
    update_stock()
    Valid(c)  
#Asking the user their name
Customer_Name=input("Please Enter Your Name: ")

#Defining the valid function with count in parameter
def Valid(c):
    c=c
    
    
#Asking the users to input costume ID which they want to buy
    try:
        RentID=int(input("Enter the ID: "))
    except ValueError:
        print("Please, Enter numeric value only")
        display()
    #Checking if the costume  is available or not
    if (RentID>0 and RentID<=c):
        print("Costume is available")
        try:
        #Asking the users to input the amount of  quantity of costume user wants
            qty=int(input("Enter the quantity you want: "))
        except ValueError:
                print("Invalid! Enter numberic value only")
                display()
        costume_select=dic_costume[RentID]
        
								
        if qty<=int(costume_select[3]):
            """CALL update_stock function
INITIALIZE the variable abcd. ASSIGN the value of abcd with index 0,1,tiday,qty of costume_select as String
APPEND the billing detail as abcd
REPLACE the value  with  by abcd variable
REPLACE the value , with empty text by abcd variable

INITIALIZE the variable custome_renting. APPEND the value abcd in custome_rent variable
INITIALIZE the variable xyz.  ASSIGN the value of xyz with variable ID, Customer_Name, Costume_select with index 0, qty, and RentID by String
REPLACE the value  by empty text in xyz

APPEND the variable xyz  in list00
"""
            print("Quantity is Available please continue")
            #Updating the stocks
            update_qty=int(costume_select[3])-qty
            costume_select[3]=str(update_qty)
            update_stock()
            abcd=[str(costume_select[0]),str(costume_select[1]),str(today),str(qty)]
            abcd = str(abcd)[1:-1] 
            abcd=abcd.replace("'"," \t")
            abcd=abcd.replace(",","")

			#Apeending the updated stoock in the list
            custome_renting.append(abcd)

            total=int(costume_select[2].rstrip("$"))*qty

            Total.append(total)

            xyz=[str(costume_select[0]),str(costume_select[1]),str(today),str(qty)]
            xyz = str(xyz)[1:-1]
            xyz=xyz.replace("'","\t")
            xyz=xyz.replace(",","")
            
            
            
            list00.append(xyz)

            Nam=[str(Customer_Name), str(ID)]
            Nam= str(Nam)[1:-1]
            Nam=Nam.replace("'","")
            Nam=Nam.replace(",","\t ")

            list01.append(Nam)
            
            
            total=int(costume_select[2].rstrip("$"))*qty
            
            Total.append(total)
            mnop=[str(costume_select[0]),str(costume_select[1]),str(today),str(qty),str(RentID),str(day)]
            mnop = str(mnop)[1:-1]
            mnop=mnop.replace("'","")
            renting.append(mnop)
           
           
            write_two()
            Nam=[str(Customer_Name), str(ID)]
            Nam= str(Nam)[1:-1]
            Nam=Nam.replace("'","")
            Nam=Nam.replace(",","\t   ")

            list01.append(Nam)
            write()


            #Asking the user if they want to continue renting or not
            billing = (input("        Do you want to continue? \n Type Yes to continue or No to exist")).lower()
            
            #Printing the bill if costumer wants to check out
            if billing=="no":
                print("\n")
                print("\t",("#"*90))
                print("\t\t\t\t\t","Shishir Clothing")
                print("\t",("#"*90))
                print("-"*120)
                print("\t\t\t\t\t", "Billing")
                print("-"*120)
                print("\t","Customer Name: ",Customer_Name)
                print("\t","Customer ID: ",ID)
                print("\t","\t""Costume","\t""Brand","\t""\t""Booked Date","\t""  " "Quantity")
                print("\t","#"*90)
                for item in custome_renting:
                    
                    print("\t",item,end="\t")
                    print("\n")
                print('\t',"Total= ",sum(Total))
                print("\t","#"*90) 
                
    #print the message if the user wants to continue renting
            elif billing=="yes":
                print("Thank you. Feel free to rent more")   
                    
                display()
            
            

        else:
            #Printing the message if the total quantity is more than the user want to rent
            print("-"*50)
            print("Sorry, Costume is out of stock.")
            print("-"*50)
            display()
    else:
        #Printing message in case of user inputs the invalid input
        print("-"*50)
        print("INVALID! Try again.")
        print("-"*50)
        display()

#def Write():
  #  ghi=open('ccrtxt.txt', 'a') 
   # for item in list00:
    #    
     #   ghi.write(str(item))
      #  ghi.write("\n")

def write_two():
    #Creating the auto generating text file to store costumer data
    ghi=open('COSTUMER'+str(ID)+".txt", 'w') 
    
    for aaaa in renting:
        ghi.write(str(aaaa))
        ghi.write("\n")
    ghi.close()


def write():
    #Creating the bill in text file for the user
    cc=open('COS_Bill'+str(ID)+".txt",'w') 
    cc.write("-"*60)
    cc.write("\n")
    cc.write("\t Shishir Clothing")
    cc.write("\n")
    cc.write("-"*60)
    cc.write("\n")
    cc.write("\t  Bill Details")
    cc.write("\n")
    cc.write("Name: ")
    cc.write(Customer_Name)
    cc.write("\n")
    cc.write("Costomer ID: ")
    cc.write(str(ID))
    cc.write("\n")
    cc.write("-"*60)
    cc.write("\n")
    cc.write("Costume")
    cc.write("\t  Brand")
    cc.write("\t   Book Date")
    cc.write("\t Quantity")
    cc.write("\n")
    cc.write("-"*60)
    cc.write("\n")
    for dd in list00:
        cc.write(str(dd))
        cc.write("\n")
    cc.write("\n")
    cc.write("-"*60)
    cc.write("\n")
    cc.write("total: ")
    cc.write(str(sum(Total)))
    cc.close() 


	
            
def update_stock():
    #Updating the stock after user rents the costume
    oo=open("Shishir.txt","w")
    for key,value in dic_costume.items():
        oo.write(",".join(value))
        oo.write("\n")
    oo.close()
display()