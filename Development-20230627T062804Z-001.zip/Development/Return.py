#import the datetime function
from datetime import date
return_date=date.today()
return_day=date.today().day
#Creating the dictionary
dic_return={}
dic_costume={}
#Creating the list
billing=[]
#Enter the costumer Id to find their data
print("-"*50)

Costumer_id=input('Enter Costumer ID: ')

print("-"*50)

#Creating a function return_dic
def return_dic():
    c=0
    #Opening the text file Shishir.txt text file
    file=open("Shishir.txt","r")
    return_data= file.read()
    return_data=return_data.split("\n")

    
    while("" in return_data):
        return_data.remove("")
    for i in range (len(return_data)):
        c=c+1
        dic_costume[c]=return_data[i].split(",")
    
    
    counter_two=0
    #Opening the auto generated text file created during renting
    file=open('COSTUMER'+str(Costumer_id)+".txt","r")
    returing_data= file.read()
    returing_data=returing_data.split("\n")
    while("" in returing_data):
        returing_data.remove("")
    for i in range (len(returing_data)):
        counter_two=counter_two+1
        dic_return[counter_two]=returing_data[i].split(",")
    Valid_data(counter_two)
    update_stock()
    #Validating the data
def Valid_data(counter_two): 
    if counter_two==1:
        identity_1=1
    else:
        for key,value in dic_return.items():
            print(key,end=":  ")
            for j in value[:1]:
                print(j,end="\t")
            print("\n")
            print("-"*50)
            #Asking the user which costume they want to return
        identity_1= input("Which costume you want to return?: ")
        print("-"*50)
    
    #DECLARE the variable selc_return. ASSIGN the variable with APPENDED identity_1 as int datatype in dic_return dictionary
    selc_return=dic_return[int(identity_1)]
    qty=int(selc_return[3])  
    """print("-"*50)
    sure=input("Type Yes to return or No to  check out! ").lower()
    print("-"*50)
    if(sure=="yes"):"""

    """DECLARE the variable list0002. ASSIGN its value with index 0,1,3 of selc_return variable
APPEND list0002 in String on index 1: -1
REPLACE the text  with empty text in list0002
REPLACE the text , with \t in list0002
APPEND the value of list0002 in billing list
APPEND the value of selc_return of index 4 in dic_costume in return_slec variable
DECLARE the variable UQDTY. APPEND the value of return_slec of index 3 and ADD with the variable qty
"""
    list0002=[selc_return[0],selc_return[1],selc_return[3]]
    list0002=str(list0002)[1:-1]
    list0002=list0002.replace("'","")
    list0002=list0002.replace(","," \t")
    billing.append(list0002)
    return_slec=dic_costume[int(selc_return[4])]           
    UQDTY=int(return_slec[3])+qty
    return_slec[3]=str(UQDTY)
    update_stock()
    print("-"*50)
    #Asking the user if they want to continue?
    Sure=input("Type Yes to return or No to  check out! ").lower()
    print("-"*50)
    if(Sure=="no"):
        update_stock()
        print("*"*60,"\n") 
        print("Thank You! \n VISIT AGAIN") 
        print("*"*60,"\n") 
        #Printing title for the bill
        print("\t \t \t \tShishir Clothing")
        print("\t \t \t \t Bill Details","\n")
        print("*"*60,"\n") 
        print("Costumer ID: " , Costumer_id,"\n")
        print("Booked date: ", selc_return[2],"\n")
        print("Return date: ",return_date,"\n")  
        print("*"*60,"\n")
        print("\t","\t""Costume","\t""Brand","\t","\t"" " "Quantity")
        print("*"*60,"\n") 
        for item in billing:        
            print("\t \t",item,end="\t\t")
            print("\n")
        print("*"*60)
        day=int(selc_return[5])
        #punishing the user with pentalty if they are late in returning the costume
        LATE=(day+5)-return_day
        if return_day<day+5:
            total=0
        else:
            LATE*5
        print("\t Total Penalty",total,"$","\n")
        print("*"*60)
    elif Sure=="yes" :
        #Printing text to appealing to continue
        print("Please continue")
        #Returning to start returning again
        return_dic()
    else:
        print("Invalid Input")
        return_dic()
        #Function to update the text in the shishir.txt text file
def update_stock():
    abc=open("Shishir.txt","w")
    for key,value in dic_costume.items():
        abc.write(",".join(value))
        abc.write("\n")
    abc.close()								
        
return_dic()